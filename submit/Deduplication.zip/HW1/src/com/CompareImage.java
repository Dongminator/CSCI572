package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.SAXException;

public class CompareImage {
	
	public static void main(String[] args) throws IOException, SAXException,
			TikaException {
		String rootPath="/Users/sx/Desktop/CSCI572/Assignments/Assignment1/nutch-trunk/runtime/local/downloadImage/";
		File file=new File(rootPath);
		String[] fileName=file.list();
		CompareImage gi=new CompareImage();
		Metadata met1=null;
		Metadata met2=null;
		for(int i=0;i<fileName.length;i++){
			met1=gi.genMetadata(rootPath+fileName[i]);
			for(int j=i+1;j<fileName.length;j++){
				met2=gi.genMetadata(rootPath+fileName[j]);
			}
		}
		//retrieve values in Metadata map into a new set
		Set<String> set1=new HashSet<String>();
		Set<String> set2=new HashSet<String>();
		for (String key : met1.names()) {
//			System.out
//					.println(key+ " : " + met1.get(key));
			set1.add(met1.get(key));
		}
		for (String key : met2.names()) {
//			System.out
//					.println(key+ " : " + met2.get(key));
			set2.add(met2.get(key));
		}
		MinHash<String> minHash=new MinHash<String>(set1.size()+set2.size());
		System.out.println(minHash.similarity(set1, set2));
	}
	
	public Metadata genMetadata(String imagePath) throws IOException, SAXException, TikaException{
		File file = new File(imagePath);
		FileInputStream fis = new FileInputStream(file);
		Parser parser = new AutoDetectParser();
		BodyContentHandler bch = new BodyContentHandler();
		Metadata met = new Metadata();
		ParseContext parseContext = new ParseContext();
		// parse the file
		parser.parse(fis, bch, met, parseContext);
		return met;
	}
}
